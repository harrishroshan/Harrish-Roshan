package com.example.wordjumble;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private TextView clueTextView;
    private TextView jumbledWordTextView;
    private TextView currentGuessTextView;
    private TextView livesTextView;
    private Button[] tileButtons;
    private Button checkButton;

    private EditText edt_GuessText;

    private List<String> wordList;
    private List<String> clueList;
    private String word;
    private String clue;
    private String jumbledWord;
    private String currentGuess;
    private int lives;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        clueTextView = findViewById(R.id.clueTextView);
        jumbledWordTextView = findViewById(R.id.jumbledWordTextView);
        currentGuessTextView = findViewById(R.id.currentGuessTextView);
        livesTextView = findViewById(R.id.livesTextView);
        tileButtons = new Button[5];
        tileButtons[0] = findViewById(R.id.tileButton1);
        tileButtons[1] = findViewById(R.id.tileButton2);
        tileButtons[2] = findViewById(R.id.tileButton3);
        tileButtons[3] = findViewById(R.id.tileButton4);
        tileButtons[4] = findViewById(R.id.tileButton5);
        checkButton = findViewById(R.id.checkButton);
        edt_GuessText = findViewById(R.id.edt_guessText);

        // Set click listeners for tile buttons and check button
        for (Button tileButton : tileButtons) {
            tileButton.setOnClickListener(this);
        }
        checkButton.setOnClickListener(this);

        // Initialize word and clue lists
        wordList = new ArrayList<>();
        wordList.add("apple");
        wordList.add("banana");
        wordList.add("orange");
        wordList.add("grape");
        wordList.add("mango");

        clueList = new ArrayList<>();
        clueList.add("A common fruit");
        clueList.add("A long, yellow fruit");
        clueList.add("A citrus fruit");
        clueList.add("A small, round fruit");
        clueList.add("A tropical fruit");

        // Start a new game
        startNewGame();
    }

    @Override
    public void onClick(View v) {
        if (v instanceof Button) {
            Button clickedButton = (Button) v;

            if (clickedButton.getId() == R.id.checkButton) {
                currentGuess = edt_GuessText.getText().toString();
                checkGuess();
            } else {
                if(clickedButton.getText().toString()!=""){
                    int tileIndex = Integer.parseInt(clickedButton.getText().toString());
                    fillTile(tileIndex);
                }

            }
        }
    }

    private void startNewGame() {
        // Reset lives and current guess
        lives = 3;
        currentGuess = "";

        // Select a random word and clue
        int randomIndex = new Random().nextInt(wordList.size());
        word = wordList.get(randomIndex);
        clue = clueList.get(randomIndex);

        // Jumble the word
        jumbledWord = jumbleWord(word);

        // Update UI elements
        clueTextView.setText(clue);
        jumbledWordTextView.setText(jumbledWord);
        currentGuessTextView.setText(currentGuess);
        currentGuess = edt_GuessText.getText().toString();
        livesTextView.setText(String.valueOf(lives));

        // Enable tile buttons
        for (Button tileButton : tileButtons) {
            tileButton.setEnabled(true);
        }
    }

    private String jumbleWord(String word) {
        List<Character> letters = new ArrayList<>();
        for (char c : word.toCharArray()) {
            letters.add(c);
        }
        Collections.shuffle(letters);

        StringBuilder jumbledWord = new StringBuilder();
        for (char c : letters) {
            jumbledWord.append(c);
        }

        return jumbledWord.toString();
    }

    private void checkGuess() {
        if (currentGuess.equals(word)) {
            // Correct guess
            clueTextView.setText("Correct! The word is: " + word);
        } else {
            // Incorrect guess
            lives--;
            livesTextView.setText(String.valueOf(lives));
            if (lives == 0) {
                // Game over
                clueTextView.setText("Game Over! The word was: " + word);
            } else {
                // Incorrect guess, continue the game
                currentGuess = "";
                currentGuessTextView.setText(currentGuess);
            }
        }
    }

    private void fillTile(int tileIndex) {
        if (currentGuess.length() < word.length()) {
            currentGuess += jumbledWord.charAt(tileIndex);
            currentGuessTextView.setText(currentGuess);
            tileButtons[tileIndex].setEnabled(false);
        }
    }
}